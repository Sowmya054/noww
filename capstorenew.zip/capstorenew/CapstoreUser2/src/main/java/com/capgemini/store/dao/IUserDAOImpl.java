package com.capgemini.store.dao;

public class IUserDAOImpl implements IUserDAO {

}
