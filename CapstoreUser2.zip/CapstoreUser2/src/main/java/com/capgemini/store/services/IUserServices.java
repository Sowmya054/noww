package com.capgemini.store.services;

public interface IUserServices {

}
