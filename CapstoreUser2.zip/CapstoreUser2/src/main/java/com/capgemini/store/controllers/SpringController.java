package com.capgemini.store.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SpringController {
	@RequestMapping("/")
	public String getIndexPage() {
		return "now1";
	}
	
	@RequestMapping("/signUpPAge")
	public String getSignIn() {
		return "signUpPage";
	}
	
	@RequestMapping("/home2")
	public String gethome2() {
		return "home2";
	}
}
