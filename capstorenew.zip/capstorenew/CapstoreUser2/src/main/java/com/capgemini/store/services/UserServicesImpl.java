package com.capgemini.store.services;

public class UserServicesImpl implements IUserServices {

}
