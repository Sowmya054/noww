package com.capgemini.store.exceptions;

public class Exceptions {

	public Exceptions() {
		super();
		// TODO Auto-generated constructor stub
	}

}
