package com.capgemini.store.dao;

public interface IUserDAO {

}
